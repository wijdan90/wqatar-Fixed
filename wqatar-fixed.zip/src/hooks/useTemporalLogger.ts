import { useCallback, useMemo, useRef, useState } from "react";

export type ActionType =
  | "session_start"
  | "session_end"
  | "task_start"
  | "task_complete"
  | "task_switch"
  | "slider_velocity"
  | "slider_angle"
  | "fire"
  | "projectile_land"
  | "reset"
  | "hint_used"
  | "task_attempt"
  | "task_success"
  | "student_notes"
  | "question_answer";

export type DerivedCode =
  | "Explore"
  | "Test"
  | "Attempt"
  | "Help"
  | "Adjust"
  | "Analyze"
  | "Confirm"
  | "Idle"
  | "Other";

export interface StateSnapshot {
  velocity: number;
  angle: number;
  projectileX: number;
  projectileY: number;
  isFlying: boolean;
  currentTask: number;
  attemptCount: number;
  hintCount: number;
  projectileType?: "football" | "bowling";
}

export interface TemporalMeta {
  gap_from_previous_ms: number;
  session_time_ms: number;
  challenge_time_ms: number;
}

export interface EventLogRow {
  sequenceNumber: number;
  timestamp_ms: number;
  actionType: ActionType;
  value: any;
  derivedCode: DerivedCode;
  state: StateSnapshot;
  temporal: TemporalMeta;
  metadata?: Record<string, any>;
}

export interface TemporalMetrics {
  sessionStartTime: number;
  sessionDurationMs: number;
  totalActions: number;

  // Challenge-level
  challengeStartTime: number | null;
  challengeDurationMs: number;

  // Counts
  explorationCount: number;
  testCount: number;
  attemptCount: number;
  helpCount: number;
  idleCount: number;

  // Ratios / rates
  exploreTestRatio: number;
  explorationDensityPerSec: number;
  testFrequencyPerSec: number;
  helpDependency: number;
  actionRatePerMin: number;

  // Latencies (ms)
  timeToFirstExploreMs: number | null;
  timeToFirstTestMs: number | null;
  timeToFirstHelpMs: number | null;

  // Gaps
  lastActionTime: number;
  currentGapMs: number;
  meanActionGapMs: number;
  exploreToTestGapsMs: number[];
  testToAdjustGapsMs: number[];

  // Patterns
  consecutiveExplores: number;
  maxConsecutiveExplores: number;
  repeatTestCount: number;
}

const defaultMetrics = (): TemporalMetrics => {
  const now = Date.now();
  return {
    sessionStartTime: now,
    sessionDurationMs: 0,
    totalActions: 0,
    challengeStartTime: null,
    challengeDurationMs: 0,
    explorationCount: 0,
    testCount: 0,
    attemptCount: 0,
    helpCount: 0,
    idleCount: 0,
    exploreTestRatio: 0,
    explorationDensityPerSec: 0,
    testFrequencyPerSec: 0,
    helpDependency: 0,
    actionRatePerMin: 0,
    timeToFirstExploreMs: null,
    timeToFirstTestMs: null,
    timeToFirstHelpMs: null,
    lastActionTime: now,
    currentGapMs: 0,
    meanActionGapMs: 0,
    exploreToTestGapsMs: [],
    testToAdjustGapsMs: [],
    consecutiveExplores: 0,
    maxConsecutiveExplores: 0,
    repeatTestCount: 0,
  };
};

function classifyDerivedCode(
  actionType: ActionType,
  gapMs: number,
  prev: EventLogRow | null,
  lastTestParams: { velocity: number; angle: number } | null,
  currentParams: { velocity: number; angle: number }
): DerivedCode {
  // Idle rule (temporal gap)
  if (gapMs >= 10_000 && gapMs < 30_000) return "Idle";

  // Base mapping
  if (actionType === "slider_velocity" || actionType === "slider_angle") {
    // If slider change occurs soon after a test -> Adjust
    if (prev && prev.actionType === "fire" && gapMs < 30_000) return "Adjust";
    return "Explore";
  }

  if (actionType === "fire") {
    // Confirm: repeated test with similar parameters
    if (
      lastTestParams &&
      Math.abs(lastTestParams.velocity - currentParams.velocity) <= 0.05 * Math.max(lastTestParams.velocity, 1) &&
      Math.abs(lastTestParams.angle - currentParams.angle) <= 3
    ) {
      return "Confirm";
    }
    return "Test";
  }

  if (actionType === "task_attempt") return "Attempt";
  if (actionType === "hint_used") return "Help";

  // Analyze: a pause-like event can be inferred when the previous action was a test
  // and the current action is not immediate (3-30s). We approximate this using gaps.
  if (prev && prev.actionType === "fire" && gapMs >= 3_000 && gapMs < 30_000) return "Analyze";

  return "Other";
}

function safeMean(nums: number[]): number {
  if (nums.length === 0) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

/**
 * Temporal logger used for RO1: stores ms timestamps, state snapshots, gaps, and derived behavioral codes.
 * It is intentionally platform-agnostic: it logs based on the simulation state you pass in.
 */
export function useTemporalLogger(getState: () => StateSnapshot) {
  const [events, setEvents] = useState<EventLogRow[]>([]);
  const [metrics, setMetrics] = useState<TemporalMetrics>(() => defaultMetrics());

  const lastTestParamsRef = useRef<{ velocity: number; angle: number } | null>(null);

  const lastEvent = useMemo(() => (events.length ? events[events.length - 1] : null), [events]);

  const updateMetrics = useCallback(
    (actionType: ActionType, gapMs: number, timestampMs: number, derivedCode: DerivedCode) => {
      setMetrics((prev) => {
        const next: TemporalMetrics = { ...prev };

        next.totalActions += 1;
        next.sessionDurationMs = timestampMs - next.sessionStartTime;
        next.lastActionTime = timestampMs;
        next.currentGapMs = gapMs;

        // Challenge duration
        if (next.challengeStartTime) next.challengeDurationMs = timestampMs - next.challengeStartTime;

        // Idle count from derived code
        if (derivedCode === "Idle") next.idleCount += 1;

        // Counts + latencies
        if (derivedCode === "Explore" || derivedCode === "Adjust") {
          next.explorationCount += 1;
          next.consecutiveExplores += 1;
          next.maxConsecutiveExplores = Math.max(next.maxConsecutiveExplores, next.consecutiveExplores);
          if (next.timeToFirstExploreMs === null) next.timeToFirstExploreMs = timestampMs - next.sessionStartTime;
        } else {
          next.consecutiveExplores = 0;
        }

        if (derivedCode === "Test" || derivedCode === "Confirm") {
          next.testCount += 1;
          if (next.timeToFirstTestMs === null) next.timeToFirstTestMs = timestampMs - next.sessionStartTime;
        }

        if (derivedCode === "Help") {
          next.helpCount += 1;
          if (next.timeToFirstHelpMs === null) next.timeToFirstHelpMs = timestampMs - next.sessionStartTime;
        }

        if (derivedCode === "Attempt") next.attemptCount += 1;

        // Ratios / rates
        const durationSec = Math.max(next.sessionDurationMs / 1000, 1);
        next.exploreTestRatio = next.explorationCount / Math.max(next.testCount, 1);
        next.explorationDensityPerSec = next.explorationCount / durationSec;
        next.testFrequencyPerSec = next.testCount / durationSec;
        next.helpDependency = next.totalActions ? next.helpCount / next.totalActions : 0;
        next.actionRatePerMin = (next.totalActions / durationSec) * 60;

        // Mean gap: we compute it from events + this gap
        const gaps = events.length
          ? [...events.slice(1).map((e, i) => e.timestamp_ms - events[i].timestamp_ms), gapMs].filter((n) => n >= 0)
          : [];
        next.meanActionGapMs = safeMean(gaps);

        // Explore->Test gap list
        const prevEv = lastEvent;
        if (actionType === "fire" && prevEv && (prevEv.actionType === "slider_velocity" || prevEv.actionType === "slider_angle")) {
          next.exploreToTestGapsMs = [...next.exploreToTestGapsMs, gapMs];
        }
        if ((actionType === "slider_velocity" || actionType === "slider_angle") && prevEv && prevEv.actionType === "fire") {
          next.testToAdjustGapsMs = [...next.testToAdjustGapsMs, gapMs];
        }

        // Repeat tests
        if (actionType === "fire" && derivedCode === "Confirm") next.repeatTestCount += 1;

        return next;
      });
    },
    [events, lastEvent]
  );

  const logEvent = useCallback(
    (actionType: ActionType, value: any = null, metadata: Record<string, any> = {}) => {
      const now = Date.now();
      const gapMs = Math.max(0, now - metrics.lastActionTime);

      const state = getState();
      const derivedCode = classifyDerivedCode(
        actionType,
        gapMs,
        lastEvent,
        lastTestParamsRef.current,
        { velocity: state.velocity, angle: state.angle }
      );

      // update last test params
      if (actionType === "fire") lastTestParamsRef.current = { velocity: state.velocity, angle: state.angle };

      const temporal: TemporalMeta = {
        gap_from_previous_ms: gapMs,
        session_time_ms: now - metrics.sessionStartTime,
        challenge_time_ms: metrics.challengeStartTime ? now - metrics.challengeStartTime : 0,
      };

      const row: EventLogRow = {
        sequenceNumber: events.length + 1,
        timestamp_ms: now,
        actionType,
        value,
        derivedCode,
        state: {
          ...state,
        },
        temporal,
        metadata,
      };

      setEvents((prev) => [...prev, row]);
      updateMetrics(actionType, gapMs, now, derivedCode);
      return row;
    },
    [events.length, getState, lastEvent, metrics.challengeStartTime, metrics.lastActionTime, metrics.sessionStartTime, updateMetrics, metrics]
  );

  const startChallenge = useCallback(
    (taskId: number, extra: Record<string, any> = {}) => {
      const now = Date.now();
      setMetrics((prev) => ({
        ...prev,
        challengeStartTime: now,
        challengeDurationMs: 0,
        // reset challenge-focused counters
        explorationCount: 0,
        testCount: 0,
        attemptCount: 0,
        helpCount: 0,
        idleCount: 0,
        timeToFirstExploreMs: null,
        timeToFirstTestMs: null,
        timeToFirstHelpMs: null,
        exploreToTestGapsMs: [],
        testToAdjustGapsMs: [],
        consecutiveExplores: 0,
        maxConsecutiveExplores: 0,
      }));
      logEvent("task_start", taskId, extra);
    },
    [logEvent]
  );

  const completeChallenge = useCallback(
    (taskId: number, success: boolean, extra: Record<string, any> = {}) => {
      logEvent("task_complete", taskId, {
        success,
        duration_ms: metrics.challengeDurationMs,
        explorations: metrics.explorationCount,
        tests: metrics.testCount,
        attempts: metrics.attemptCount,
        hints: metrics.helpCount,
        explore_test_ratio: metrics.exploreTestRatio,
        ...extra,
      });
    },
    [logEvent, metrics]
  );

  const resetSession = useCallback(() => {
    setEvents([]);
    setMetrics(defaultMetrics());
    lastTestParamsRef.current = null;
  }, []);

  return {
    events,
    metrics,
    logEvent,
    startChallenge,
    completeChallenge,
    resetSession,
  };
}
