import { useState, useCallback, useRef, useEffect } from "react";
import {
  generateSessionId,
  resetSequenceCounter,
  logSessionEvent,
  upsertSessionMetadata,
  writeTemporalMetrics,
  writeChallengeSummary,
  ProjectileType,
} from "@/lib/firebase";
import { celebrateSuccess, celebrateAllComplete } from "@/lib/confetti";
import { useTemporalLogger, StateSnapshot } from "@/hooks/useTemporalLogger";

export interface ProjectileState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  time: number;
  maxHeight: number;
  range: number;
}

const GRAVITY = 9.81;
const SCALE = 10; // pixels per meter
const GROUND_Y = 300;

// Projectile properties for physics calculations
const PROJECTILE_PROPERTIES: Record<
  ProjectileType,
  { mass: number; dragCoefficient: number; crossSectionalArea: number }
> = {
  football: {
    mass: 0.43,
    dragCoefficient: 0.25,
    crossSectionalArea: 0.038,
  },
  bowling: {
    mass: 7.26,
    dragCoefficient: 0.47,
    crossSectionalArea: 0.046,
  },
};

const AIR_DENSITY = 1.225;

export const useProjectileSimulation = (projectileType: ProjectileType = "football") => {
  const [sessionId] = useState(() => generateSessionId());

  // Core sim state
  const [velocity, setVelocity] = useState(20);
  const [angle, setAngle] = useState(45);
  const [isFlying, setIsFlying] = useState(false);
  const [projectile, setProjectile] = useState<ProjectileState>({
    x: 50,
    y: GROUND_Y,
    vx: 0,
    vy: 0,
    time: 0,
    maxHeight: 0,
    range: 0,
  });
  const [trajectory, setTrajectory] = useState<{ x: number; y: number }[]>([]);
  const [currentTask, setCurrentTask] = useState(0);

  // Task/learner fields
  const [attemptCounts, setAttemptCounts] = useState([0, 0, 0]);
  const [taskSuccesses, setTaskSuccesses] = useState([false, false, false]);

  // Keep both: boolean for UI + count for logging
  const [hintsUsed, setHintsUsed] = useState([false, false, false]);
  const [hintCounts, setHintCounts] = useState([0, 0, 0]);

  const [studentNotes, setStudentNotes] = useState("");
  const [questionAnswers, setQuestionAnswers] = useState(["", ""]);
  const [taskTimers, setTaskTimers] = useState<number[]>([0, 0, 0]); // seconds spent per task

  const animationRef = useRef<number>();
  const startTimeRef = useRef<number>(0);
  const taskStartTimeRef = useRef<number>(Date.now());
  const projectileTypeRef = useRef<ProjectileType>(projectileType);

  // Update ref when projectileType changes
  useEffect(() => {
    projectileTypeRef.current = projectileType;
  }, [projectileType]);

  const tasks = [
    {
      description: "Hit the target at 15m",
      descriptionAr: "أصب الهدف على بعد 15 متر",
      targetDistance: 15,
      tolerance: 1,
    },
    {
      description: "Achieve maximum height of 10m",
      descriptionAr: "حقق ارتفاع أقصى 10 أمتار",
      targetHeight: 10,
      tolerance: 1,
    },
    {
      description: "Hit the target at 30m with angle < 60°",
      descriptionAr: "أصب الهدف على بعد 30 متر بزاوية أقل من 60 درجة",
      targetDistance: 30,
      maxAngle: 60,
      tolerance: 1.5,
    },
  ] as const;

  const getStateSnapshot = useCallback((): StateSnapshot => {
    return {
      velocity,
      angle,
      projectileX: projectile.x,
      projectileY: projectile.y,
      isFlying,
      currentTask,
      attemptCount: attemptCounts[currentTask] ?? 0,
      hintCount: hintCounts[currentTask] ?? 0,
      projectileType: projectileTypeRef.current,
    };
  }, [velocity, angle, projectile, isFlying, currentTask, attemptCounts, hintCounts]);

  const temporal = useTemporalLogger(getStateSnapshot);

  // ---- Firebase session metadata (once) ----
  useEffect(() => {
    // metadata is safe and non-identifying by default
    upsertSessionMetadata(sessionId, {
      createdAt_ms: Date.now(),
      userAgent: navigator.userAgent,
      screen: `${window.screen.width}x${window.screen.height}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      app: "wqatar-projectile-lab",
    }).catch(console.error);

    // log session_start event
    const row = temporal.logEvent("session_start", null, { sessionId });
    logSessionEvent(sessionId, {
      timestamp_ms: row.timestamp_ms,
      actionType: row.actionType,
      value: row.value,
      derivedCode: row.derivedCode,
      state: row.state,
      temporal: row.temporal,
      metadata: row.metadata,
    }).catch(console.error);

    // start first challenge (task 0)
    temporal.startChallenge(0, { taskLabel: tasks[0].description });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // periodically persist metrics (lightweight)
  useEffect(() => {
    const id = window.setInterval(() => {
      writeTemporalMetrics(sessionId, temporal.metrics as any).catch(() => {});
    }, 3000);
    return () => window.clearInterval(id);
  }, [sessionId, temporal.metrics]);

  const sendRowToFirebase = useCallback(
    async (row: ReturnType<typeof temporal.logEvent>) => {
      await logSessionEvent(sessionId, {
        timestamp_ms: row.timestamp_ms,
        actionType: row.actionType,
        value: row.value,
        derivedCode: row.derivedCode,
        state: row.state,
        temporal: row.temporal,
        metadata: row.metadata,
      });
    },
    [sessionId]
  );

  // Helper to log + persist
  const logAndPersist = useCallback(
    async (actionType: any, value: any, metadata: Record<string, any> = {}) => {
      const row = temporal.logEvent(actionType, value, metadata);
      await sendRowToFirebase(row);
      return row;
    },
    [sendRowToFirebase, temporal]
  );

  const handleVelocityChange = useCallback(
    (newVelocity: number) => {
      setVelocity(newVelocity);
      logAndPersist("slider_velocity", newVelocity);
    },
    [logAndPersist]
  );

  const handleAngleChange = useCallback(
    (newAngle: number) => {
      setAngle(newAngle);
      logAndPersist("slider_angle", newAngle);
    },
    [logAndPersist]
  );

  // Track task time when switching tasks
  const handleTaskSwitch = useCallback(
    (newTask: number) => {
      const now = Date.now();

      // Save time spent on current task (seconds)
      const timeSpent = (now - taskStartTimeRef.current) / 1000;
      setTaskTimers((prev) => {
        const updated = [...prev];
        updated[currentTask] = (prev[currentTask] ?? 0) + timeSpent;
        return updated;
      });

      // Log task switch
      logAndPersist("task_switch", { from: currentTask, to: newTask, timeSpent_s: timeSpent });

      // Reset timer for new task
      taskStartTimeRef.current = now;
      setCurrentTask(newTask);

      // Start new challenge window for temporal metrics
      temporal.startChallenge(newTask, { taskLabel: tasks[newTask]?.description });
    },
    [currentTask, logAndPersist, tasks, temporal]
  );

  const checkTaskCompletion = useCallback(
    async (finalRange: number, maxHeight: number) => {
      const task = tasks[currentTask];
      let success = false;

      if (currentTask === 0) {
        success = Math.abs(finalRange - task.targetDistance) < task.tolerance;
      } else if (currentTask === 1) {
        success = Math.abs(maxHeight - task.targetHeight) < task.tolerance;
      } else if (currentTask === 2) {
        success =
          Math.abs(finalRange - task.targetDistance) < task.tolerance && angle < task.maxAngle;
      }

      if (success && !taskSuccesses[currentTask]) {
        // Final time for this task
        const timeSpent = (Date.now() - taskStartTimeRef.current) / 1000;
        const updatedTimers = [...taskTimers];
        updatedTimers[currentTask] = (taskTimers[currentTask] ?? 0) + timeSpent;
        setTaskTimers(updatedTimers);

        const newSuccesses = [...taskSuccesses];
        newSuccesses[currentTask] = true;
        setTaskSuccesses(newSuccesses);

        // log task_success + task_complete summary (temporal)
        await logAndPersist("task_success", { task: currentTask, timeSpent_s: updatedTimers[currentTask] });
        temporal.completeChallenge(currentTask, true, { timeSpent_s: updatedTimers[currentTask] });
        await sendRowToFirebase(
          temporal.logEvent("task_complete", currentTask, {
            success: true,
            timeSpent_s: updatedTimers[currentTask],
          })
        );

        // write per-challenge summary to DB
        writeChallengeSummary(sessionId, currentTask, {
          taskId: currentTask,
          success: true,
          duration_s: updatedTimers[currentTask],
          attempts: attemptCounts[currentTask] ?? 0,
          hints: hintCounts[currentTask] ?? 0,
          exploreTestRatio: temporal.metrics.exploreTestRatio,
        }).catch(() => {});

        // Reset timer for next task attempt
        taskStartTimeRef.current = Date.now();

        if (newSuccesses.every((s) => s)) celebrateAllComplete();
        else celebrateSuccess();
      }

      return success;
    },
    [
      angle,
      attemptCounts,
      currentTask,
      hintCounts,
      logAndPersist,
      sendRowToFirebase,
      sessionId,
      taskSuccesses,
      taskTimers,
      tasks,
      temporal,
    ]
  );

  const fire = useCallback(() => {
    if (isFlying) return;

    const newAttempts = [...attemptCounts];
    newAttempts[currentTask] = (newAttempts[currentTask] ?? 0) + 1;
    setAttemptCounts(newAttempts);

    // log test + attempt
    logAndPersist("fire", null);
    logAndPersist("task_attempt", currentTask);

    const angleRad = (angle * Math.PI) / 180;
    const vx = velocity * Math.cos(angleRad);
    const vy = -velocity * Math.sin(angleRad);

    setProjectile({
      x: 50,
      y: GROUND_Y,
      vx,
      vy,
      time: 0,
      maxHeight: 0,
      range: 0,
    });
    setTrajectory([{ x: 50, y: GROUND_Y }]);
    setIsFlying(true);
    startTimeRef.current = performance.now();
  }, [isFlying, attemptCounts, currentTask, logAndPersist, velocity, angle]);

  const reset = useCallback(() => {
    if (animationRef.current) cancelAnimationFrame(animationRef.current);

    setProjectile({
      x: 50,
      y: GROUND_Y,
      vx: 0,
      vy: 0,
      time: 0,
      maxHeight: 0,
      range: 0,
    });
    setTrajectory([]);
    setIsFlying(false);
    logAndPersist("reset", null);
  }, [logAndPersist]);

  const fullReset = useCallback(() => {
    reset();
    setVelocity(20);
    setAngle(45);
    setAttemptCounts([0, 0, 0]);
    setTaskSuccesses([false, false, false]);
    setHintsUsed([false, false, false]);
    setHintCounts([0, 0, 0]);
    setStudentNotes("");
    setQuestionAnswers(["", ""]);
    setTaskTimers([0, 0, 0]);
    setCurrentTask(0);
    taskStartTimeRef.current = Date.now();
    resetSequenceCounter();
    temporal.resetSession();
    temporal.startChallenge(0, { taskLabel: tasks[0].description });
  }, [reset, tasks, temporal]);

  const useHint = useCallback(
    (taskIndex: number) => {
      // UI boolean
      if (!hintsUsed[taskIndex]) {
        const newHintsUsed = [...hintsUsed];
        newHintsUsed[taskIndex] = true;
        setHintsUsed(newHintsUsed);
      }
      // counter
      setHintCounts((prev) => {
        const next = [...prev];
        next[taskIndex] = (next[taskIndex] ?? 0) + 1;
        return next;
      });
      logAndPersist("hint_used", taskIndex);
    },
    [hintsUsed, logAndPersist]
  );

  const handleNotesChange = useCallback(
    (notes: string) => {
      setStudentNotes(notes);
      logAndPersist("student_notes", notes.slice(0, 200));
    },
    [logAndPersist]
  );

  const handleQuestionAnswer = useCallback(
    (questionIndex: number, answer: string) => {
      setQuestionAnswers((prev) => {
        const next = [...prev];
        next[questionIndex] = answer;
        return next;
      });
      logAndPersist("question_answer", { questionIndex, answer: answer.slice(0, 200) });
    },
    [logAndPersist]
  );

  // physics animation loop
  useEffect(() => {
    if (!isFlying) return;

    const props = PROJECTILE_PROPERTIES[projectileTypeRef.current];
    const dt = 0.016;

    const animate = (currentTime: number) => {
      const elapsed = (currentTime - startTimeRef.current) / 1000;

      setProjectile((prev) => {
        const velocityMagnitude = Math.sqrt(prev.vx * prev.vx + prev.vy * prev.vy);
        const dragForce =
          0.5 * AIR_DENSITY * props.dragCoefficient * props.crossSectionalArea * velocityMagnitude * velocityMagnitude;
        const dragAccel = dragForce / props.mass;

        let dragAx = 0;
        let dragAy = 0;
        if (velocityMagnitude > 0) {
          dragAx = -dragAccel * (prev.vx / velocityMagnitude);
          dragAy = -dragAccel * (prev.vy / velocityMagnitude);
        }

        const newVx = prev.vx + dragAx * dt;
        const newVy = prev.vy + (GRAVITY + dragAy) * dt;
        const newX = prev.x + newVx * SCALE * dt;
        const newY = prev.y + newVy * SCALE * dt;

        const currentHeight = (GROUND_Y - newY) / SCALE;
        const newMaxHeight = Math.max(prev.maxHeight, currentHeight);
        const newRange = (newX - 50) / SCALE;

        if (newY >= GROUND_Y) {
          setIsFlying(false);

          // log landing error to target (if applicable)
          const t = tasks[currentTask] as any;
          const targetDistance = t.targetDistance ?? null;
          const error = targetDistance !== null ? newRange - targetDistance : null;
          logAndPersist("projectile_land", error, {
            range_m: newRange,
            maxHeight_m: newMaxHeight,
            targetDistance_m: targetDistance,
          });

          // check completion
          checkTaskCompletion(newRange, newMaxHeight);
          return {
            ...prev,
            y: GROUND_Y,
            vy: 0,
            vx: 0,
            maxHeight: newMaxHeight,
            range: newRange,
          };
        }

        setTrajectory((t) => [...t, { x: newX, y: newY }]);

        return {
          ...prev,
          x: newX,
          y: newY,
          vx: newVx,
          vy: newVy,
          time: elapsed,
          maxHeight: newMaxHeight,
          range: newRange,
        };
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isFlying, checkTaskCompletion, currentTask, logAndPersist, tasks]);

  return {
    velocity,
    angle,
    isFlying,
    projectile,
    trajectory,
    currentTask,
    attemptCounts,
    taskSuccesses,
    hintsUsed,
    hintCounts,
    studentNotes,
    questionAnswers,
    taskTimers,
    tasks,
    sessionId,
    metrics: temporal.metrics,
    events: temporal.events,
    setVelocity: handleVelocityChange,
    setAngle: handleAngleChange,
    setCurrentTask: handleTaskSwitch,
    fire,
    reset,
    fullReset,
    useHint,
    handleNotesChange,
    handleQuestionAnswer,
  };
};
