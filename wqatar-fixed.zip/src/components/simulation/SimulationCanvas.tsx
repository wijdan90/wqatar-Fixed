import React, { useRef, useEffect } from 'react';

type ProjectileType = 'football' | 'bowling';

interface SimulationCanvasProps {
  velocity: number;
  angle: number;
  projectile: { x: number; y: number };
  trajectory: { x: number; y: number }[];
  isFlying: boolean;
  projectileType: ProjectileType;
}

const GROUND_Y = 300;
const SCALE = 10;

export const SimulationCanvas: React.FC<SimulationCanvasProps> = ({
  velocity,
  angle,
  projectile,
  trajectory,
  isFlying,
  projectileType,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = 'hsl(222, 47%, 8%)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = 'hsl(222, 20%, 20%)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= canvas.width; i += SCALE * 5) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, GROUND_Y);
      ctx.stroke();
    }
    for (let i = 0; i <= GROUND_Y; i += SCALE * 5) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width, i);
      ctx.stroke();
    }

    // Draw ground with Gulf-inspired gradient
    const groundGradient = ctx.createLinearGradient(0, GROUND_Y, 0, canvas.height);
    groundGradient.addColorStop(0, 'hsl(35, 60%, 25%)');
    groundGradient.addColorStop(1, 'hsl(35, 50%, 15%)');
    ctx.fillStyle = groundGradient;
    ctx.fillRect(0, GROUND_Y, canvas.width, canvas.height - GROUND_Y);

    // Draw distance markers
    ctx.fillStyle = 'hsl(45, 80%, 65%)';
    ctx.font = '12px monospace';
    for (let i = 0; i <= 50; i += 5) {
      const x = 50 + i * SCALE;
      ctx.fillText(`${i}m`, x - 8, GROUND_Y + 20);
      ctx.beginPath();
      ctx.moveTo(x, GROUND_Y);
      ctx.lineTo(x, GROUND_Y + 5);
      ctx.strokeStyle = 'hsl(45, 80%, 65%)';
      ctx.stroke();
    }

    // Draw height markers
    for (let i = 0; i <= 25; i += 5) {
      const y = GROUND_Y - i * SCALE;
      ctx.fillText(`${i}m`, 5, y + 4);
      ctx.beginPath();
      ctx.moveTo(45, y);
      ctx.lineTo(50, y);
      ctx.stroke();
    }

    // Draw cannon base
    ctx.fillStyle = 'hsl(200, 50%, 30%)';
    ctx.beginPath();
    ctx.arc(50, GROUND_Y, 15, Math.PI, 0);
    ctx.fill();

    // Draw cannon barrel
    const angleRad = (-angle * Math.PI) / 180;
    const barrelLength = 40;
    const barrelEndX = 50 + Math.cos(angleRad) * barrelLength;
    const barrelEndY = GROUND_Y + Math.sin(angleRad) * barrelLength;

    ctx.strokeStyle = 'hsl(200, 60%, 45%)';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(50, GROUND_Y);
    ctx.lineTo(barrelEndX, barrelEndY);
    ctx.stroke();

    // Draw velocity indicator
    const velocityIndicatorLength = (velocity / 50) * 30;
    ctx.strokeStyle = 'hsl(45, 90%, 55%)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(barrelEndX, barrelEndY);
    ctx.lineTo(
      barrelEndX + Math.cos(angleRad) * velocityIndicatorLength,
      barrelEndY + Math.sin(angleRad) * velocityIndicatorLength
    );
    ctx.stroke();

    // Draw trajectory
    if (trajectory.length > 1) {
      ctx.strokeStyle = 'hsla(180, 70%, 50%, 0.6)';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(trajectory[0].x, trajectory[0].y);
      trajectory.forEach(point => {
        ctx.lineTo(point.x, point.y);
      });
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw projectile based on type
    if (isFlying || trajectory.length > 0) {
      const isFootball = projectileType === 'football';
      const projectileRadius = isFootball ? 8 : 12;
      const glowColor = isFootball ? 'hsl(120, 70%, 45%)' : 'hsl(280, 60%, 50%)';
      const coreColor = isFootball ? 'hsl(120, 60%, 50%)' : 'hsl(280, 40%, 35%)';

      // Glow effect
      const gradient = ctx.createRadialGradient(
        projectile.x, projectile.y, 0,
        projectile.x, projectile.y, projectileRadius * 2.5
      );
      gradient.addColorStop(0, `${glowColor.replace(')', ', 0.8)')}`);
      gradient.addColorStop(0.5, `${glowColor.replace(')', ', 0.3)')}`);
      gradient.addColorStop(1, `${glowColor.replace(')', ', 0)')}`);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(projectile.x, projectile.y, projectileRadius * 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Projectile body
      ctx.fillStyle = coreColor;
      ctx.beginPath();
      ctx.arc(projectile.x, projectile.y, projectileRadius, 0, Math.PI * 2);
      ctx.fill();

      // Add pattern for football (pentagon shapes)
      if (isFootball) {
        ctx.fillStyle = 'hsl(0, 0%, 20%)';
        ctx.beginPath();
        ctx.arc(projectile.x, projectile.y, projectileRadius * 0.4, 0, Math.PI * 2);
        ctx.fill();
      }

      // Add holes pattern for bowling ball
      if (!isFootball) {
        ctx.fillStyle = 'hsl(280, 30%, 25%)';
        const holeOffset = projectileRadius * 0.4;
        ctx.beginPath();
        ctx.arc(projectile.x - holeOffset, projectile.y - holeOffset, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(projectile.x + holeOffset, projectile.y - holeOffset, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(projectile.x, projectile.y + holeOffset * 0.5, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.strokeStyle = isFootball ? 'hsl(120, 70%, 60%)' : 'hsl(280, 50%, 45%)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(projectile.x, projectile.y, projectileRadius, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw target markers at specific distances
    [15, 30].forEach(distance => {
      const targetX = 50 + distance * SCALE;
      ctx.fillStyle = 'hsla(0, 70%, 50%, 0.8)';
      ctx.beginPath();
      ctx.moveTo(targetX, GROUND_Y);
      ctx.lineTo(targetX - 8, GROUND_Y - 20);
      ctx.lineTo(targetX + 8, GROUND_Y - 20);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'hsl(0, 80%, 60%)';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

  }, [velocity, angle, projectile, trajectory, isFlying, projectileType]);

  return (
    <canvas
      ref={canvasRef}
      width={600}
      height={400}
      className="rounded-xl border border-gulf-gold/20 shadow-2xl"
    />
  );
};
