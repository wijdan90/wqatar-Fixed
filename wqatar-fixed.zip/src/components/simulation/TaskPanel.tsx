import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Target, CheckCircle2, Circle, Lightbulb, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Task {
  description: string;
  descriptionAr: string;
  targetDistance?: number;
  targetHeight?: number;
  maxAngle?: number;
  tolerance: number;
}

interface TaskPanelProps {
  tasks: Task[];
  currentTask: number;
  attemptCounts: number[];
  taskSuccesses: boolean[];
  hintsUsed: boolean[];
  taskTimers: number[];
  onTaskSelect: (index: number) => void;
  onHintClick: (taskIndex: number) => void;
  onNotesChange: (notes: string) => void;
  onQuestionAnswer: (questionIndex: number, answer: string) => void;
  studentNotes: string;
  questionAnswers: string[];
}

const hints = [
  {
    en: "For maximum range, try an angle around 45°. The range formula is R = v²sin(2θ)/g",
    ar: "للحصول على أقصى مدى، جرب زاوية حوالي 45 درجة. معادلة المدى هي R = v²sin(2θ)/g"
  },
  {
    en: "Maximum height depends on vertical velocity. H = v²sin²(θ)/(2g). Try a high angle!",
    ar: "يعتمد الارتفاع الأقصى على السرعة العمودية. H = v²sin²(θ)/(2g). جرب زاوية عالية!"
  },
  {
    en: "You need to hit 30m with angle < 60°. This requires a higher velocity with a moderate angle.",
    ar: "تحتاج لضرب 30 متر بزاوية أقل من 60 درجة. هذا يتطلب سرعة أعلى مع زاوية معتدلة."
  },
];

const questions = [
  {
    en: "What happens to the range when you increase the angle from 30° to 45°?",
    ar: "ماذا يحدث للمدى عندما تزيد الزاوية من 30 إلى 45 درجة؟"
  },
  {
    en: "How does velocity affect the maximum height of the projectile?",
    ar: "كيف تؤثر السرعة على الارتفاع الأقصى للمقذوف؟"
  }
];

export const TaskPanel: React.FC<TaskPanelProps> = ({
  tasks,
  currentTask,
  attemptCounts,
  taskSuccesses,
  hintsUsed,
  taskTimers,
  onTaskSelect,
  onHintClick,
  onNotesChange,
  onQuestionAnswer,
  studentNotes,
  questionAnswers,
}) => {
  const [showHints, setShowHints] = useState<boolean[]>([false, false, false]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  const handleHintClick = (taskIndex: number) => {
    const newShowHints = [...showHints];
    newShowHints[taskIndex] = !newShowHints[taskIndex];
    setShowHints(newShowHints);
    
    if (!showHints[taskIndex] && !hintsUsed[taskIndex]) {
      onHintClick(taskIndex);
    }
  };

  return (
    <Card className="bg-card/80 backdrop-blur border-gulf-gold/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-gulf-gold flex items-center gap-2 text-sm">
          <Target className="w-4 h-4" />
          <span>Challenges • التحديات</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {tasks.map((task, index) => (
          <div key={index} className="space-y-2">
            <button
              onClick={() => onTaskSelect(index)}
              className={cn(
                "w-full text-left p-3 rounded-lg border-2 transition-all duration-200",
                currentTask === index
                  ? "border-gulf-gold bg-gulf-gold/10"
                  : "border-border/50 bg-background/30 hover:border-gulf-gold/50",
                taskSuccesses[index] && "border-green-500/50 bg-green-500/10"
              )}
            >
              <div className="flex items-start gap-2">
                <div className="mt-0.5">
                  {taskSuccesses[index] ? (
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                  ) : (
                    <Circle className={cn(
                      "w-4 h-4",
                      currentTask === index ? "text-gulf-gold" : "text-muted-foreground"
                    )} />
                  )}
                </div>
                <div className="flex-1">
                  <div className="font-medium text-xs mb-1">
                    Challenge {index + 1} • تحدي {index + 1}
                  </div>
                  <div className="text-[11px] text-muted-foreground mb-1">
                    {task.description}
                  </div>
                  <div className="text-[11px] text-muted-foreground mb-2" dir="rtl">
                    {task.descriptionAr}
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                      Attempts • محاولات: {attemptCounts[index]}
                    </Badge>
                    {taskTimers[index] > 0 && (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-blue-500/50 text-blue-400">
                        ⏱ {formatTime(taskTimers[index])}
                      </Badge>
                    )}
                    {hintsUsed[index] && (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-yellow-500/50 text-yellow-500">
                        Hint used • تلميح
                      </Badge>
                    )}
                    {taskSuccesses[index] && (
                      <Badge className="bg-green-500/20 text-green-400 text-[10px] px-1.5 py-0">
                        ✓ Done • تم
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </button>

            {/* Per-challenge hint button */}
            {currentTask === index && (
              <div className="ml-6">
                <Button
                  onClick={() => handleHintClick(index)}
                  variant="ghost"
                  size="sm"
                  className="h-6 text-[10px] text-yellow-500 hover:bg-yellow-500/10 px-2"
                >
                  <Lightbulb className="w-3 h-3 mr-1" />
                  {showHints[index] ? 'Hide Hint • إخفاء' : 'Need Hint? • تلميح؟'}
                </Button>
                
                {showHints[index] && (
                  <div className="mt-2 p-2 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                    <p className="text-[11px] text-yellow-200/90 mb-1">
                      💡 {hints[index].en}
                    </p>
                    <p className="text-[11px] text-yellow-200/70" dir="rtl">
                      {hints[index].ar}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {/* Student Notes Section */}
        <div className="pt-3 border-t border-border/50 space-y-2">
          <div className="flex items-center gap-2 text-xs font-medium text-gulf-teal">
            <MessageSquare className="w-3 h-3" />
            <span>Your Observations • ملاحظاتك</span>
          </div>
          <Textarea
            placeholder="Write what you noticed... اكتب ما لاحظته..."
            value={studentNotes}
            onChange={(e) => onNotesChange(e.target.value)}
            className="min-h-[60px] text-xs bg-background/50 border-border/50 resize-none"
          />
        </div>

        {/* Reflection Questions */}
        <div className="space-y-3">
          <div className="text-xs font-medium text-gulf-gold">
            Questions • أسئلة
          </div>
          {questions.map((q, index) => (
            <div key={index} className="space-y-1">
              <div className="text-[11px] text-foreground/80">
                {index + 1}. {q.en}
              </div>
              <div className="text-[11px] text-muted-foreground" dir="rtl">
                {q.ar}
              </div>
              <Textarea
                placeholder="Your answer... إجابتك..."
                value={questionAnswers[index] || ''}
                onChange={(e) => onQuestionAnswer(index, e.target.value)}
                className="min-h-[40px] text-xs bg-background/50 border-border/50 resize-none"
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
