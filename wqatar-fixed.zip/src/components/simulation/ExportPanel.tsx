import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Database, Loader2 } from "lucide-react";
import { getSessionLogs, ActionLog } from "@/lib/firebase";

interface ExportPanelProps {
  sessionId: string;
}

function csvEscape(value: unknown): string {
  if (value === null || value === undefined) return "";
  const str = typeof value === "string" ? value : JSON.stringify(value);
  const escaped = str.replace(/"/g, '""');
  return `"${escaped}"`;
}

function downloadFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export const ExportPanel: React.FC<ExportPanelProps> = ({ sessionId }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [logCount, setLogCount] = useState<number | null>(null);

  const exportToCSV = async () => {
    setIsExporting(true);
    try {
      const logs = await getSessionLogs(sessionId);
      setLogCount(logs.length);

      if (logs.length === 0) {
        alert("No data to export. Perform some actions first!");
        return;
      }

      const headers = [
        // core
        "sequenceNumber",
        "timestamp_ms",
        "actionType",
        "derivedCode",
        "value",

        // temporal
        "gap_from_previous_ms",
        "session_time_ms",
        "challenge_time_ms",

        // state snapshot
        "state_velocity",
        "state_angle",
        "state_projectileX",
        "state_projectileY",
        "state_isFlying",
        "state_currentTask",
        "state_attemptCount",
        "state_hintCount",
        "state_projectileType",

        // metadata
        "metadata_json",
      ];

      const rows: string[] = [headers.join(",")];

      logs.forEach((log: ActionLog) => {
        const row = [
          String(log.sequenceNumber ?? ""),
          String(log.timestamp_ms ?? ""),
          csvEscape(log.actionType),
          csvEscape(log.derivedCode ?? ""),
          csvEscape(log.value),

          String(log.temporal?.gap_from_previous_ms ?? ""),
          String(log.temporal?.session_time_ms ?? ""),
          String(log.temporal?.challenge_time_ms ?? ""),

          String(log.state?.velocity ?? ""),
          String(log.state?.angle ?? ""),
          String(log.state?.projectileX ?? ""),
          String(log.state?.projectileY ?? ""),
          String(log.state?.isFlying ?? ""),
          String(log.state?.currentTask ?? ""),
          String(log.state?.attemptCount ?? ""),
          String(log.state?.hintCount ?? ""),
          csvEscape(log.state?.projectileType ?? ""),

          csvEscape(log.metadata ?? {}),
        ];

        rows.push(row.join(","));
      });

      const csvContent = rows.join("\n");
      const filename = `session_${sessionId}_events.csv`;
      downloadFile(filename, csvContent, "text/csv;charset=utf-8");
      alert(`Exported ${logs.length} events to CSV.`);
    } catch (error) {
      console.error("Export error:", error);
      alert("Export failed. Check console for details.");
    } finally {
      setIsExporting(false);
    }
  };

  const exportToJSON = async () => {
    setIsExporting(true);
    try {
      const logs = await getSessionLogs(sessionId);
      setLogCount(logs.length);

      if (logs.length === 0) {
        alert("No data to export. Perform some actions first!");
        return;
      }

      const filename = `session_${sessionId}_events.json`;
      downloadFile(filename, JSON.stringify({ sessionId, events: logs }, null, 2), "application/json");
      alert(`Exported ${logs.length} events to JSON.`);
    } catch (error) {
      console.error("Export error:", error);
      alert("Export failed. Check console for details.");
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Card className="bg-card/80 backdrop-blur border-gulf-gold/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-gulf-gold flex items-center gap-2 text-sm">
          <Database className="w-4 h-4" />
          <span>Export Data • تصدير البيانات</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-xs text-muted-foreground">
          Session: <span className="font-mono">{sessionId}</span>
          {logCount !== null && <span className="ml-2">• Events: {logCount}</span>}
        </div>

        <div className="flex flex-col gap-2">
          <Button
            onClick={exportToCSV}
            disabled={isExporting}
            className="bg-gulf-teal hover:bg-gulf-teal/90 text-white"
          >
            {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Export CSV
          </Button>

          <Button
            onClick={exportToJSON}
            disabled={isExporting}
            variant="outline"
            className="border-gulf-gold/30"
          >
            {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Export JSON
          </Button>
        </div>

        <div className="text-[11px] text-muted-foreground leading-relaxed">
          CSV includes ms timestamps, state snapshots, temporal gaps, and derived behavior codes (Explore/Test/Adjust/Confirm/Idle).
        </div>
      </CardContent>
    </Card>
  );
};
