import React from 'react';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Gauge } from 'lucide-react';

type ProjectileType = 'football' | 'bowling';

interface ControlPanelProps {
  velocity: number;
  angle: number;
  isFlying: boolean;
  projectile: { range: number; maxHeight: number; time: number };
  projectileType: ProjectileType;
  onVelocityChange: (value: number) => void;
  onAngleChange: (value: number) => void;
  onProjectileTypeChange: (type: ProjectileType) => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  velocity,
  angle,
  isFlying,
  projectile,
  projectileType,
  onVelocityChange,
  onAngleChange,
  onProjectileTypeChange,
}) => {
  return (
    <Card className="bg-card/80 backdrop-blur border-gulf-gold/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-gulf-gold flex items-center gap-2 text-sm">
          <Gauge className="w-4 h-4" />
          <span>Controls • التحكم</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Projectile Type Selector */}
        <div className="space-y-1">
          <label className="text-xs font-medium text-foreground/80">
            Projectile • المقذوف
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onProjectileTypeChange('football')}
              disabled={isFlying}
              className={`p-2 rounded-lg border text-center transition-all ${
                projectileType === 'football'
                  ? 'border-gulf-gold bg-gulf-gold/20 text-gulf-gold'
                  : 'border-border/50 bg-background/50 text-muted-foreground hover:border-gulf-gold/50'
              } ${isFlying ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="text-lg">⚽</div>
              <div className="text-[10px]">Football</div>
              <div className="text-[10px]" dir="rtl">كرة قدم</div>
              <div className="text-[9px] text-muted-foreground">0.43 kg</div>
            </button>
            <button
              onClick={() => onProjectileTypeChange('bowling')}
              disabled={isFlying}
              className={`p-2 rounded-lg border text-center transition-all ${
                projectileType === 'bowling'
                  ? 'border-gulf-teal bg-gulf-teal/20 text-gulf-teal'
                  : 'border-border/50 bg-background/50 text-muted-foreground hover:border-gulf-teal/50'
              } ${isFlying ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="text-lg">🎳</div>
              <div className="text-[10px]">Bowling</div>
              <div className="text-[10px]" dir="rtl">كرة بولينج</div>
              <div className="text-[9px] text-muted-foreground">7.26 kg</div>
            </button>
          </div>
        </div>

        {/* Velocity Slider - Compact */}
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-xs font-medium text-foreground/80">
              Velocity • السرعة
            </label>
            <span className="text-gulf-gold font-mono font-bold text-sm">
              {velocity} m/s
            </span>
          </div>
          <Slider
            value={[velocity]}
            onValueChange={(v) => onVelocityChange(v[0])}
            min={5}
            max={50}
            step={1}
            disabled={isFlying}
            className="w-full"
          />
        </div>

        {/* Angle Slider - Compact */}
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-xs font-medium text-foreground/80">
              Angle • الزاوية
            </label>
            <span className="text-gulf-teal font-mono font-bold text-sm">
              {angle}°
            </span>
          </div>
          <Slider
            value={[angle]}
            onValueChange={(v) => onAngleChange(v[0])}
            min={0}
            max={90}
            step={1}
            disabled={isFlying}
            className="w-full"
          />
        </div>

        {/* Stats Display - Compact */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/50">
          <div className="bg-background/50 rounded-lg p-2 text-center">
            <div className="text-[10px] text-muted-foreground">Range • المدى</div>
            <div className="text-gulf-gold font-mono font-bold text-sm">
              {projectile.range.toFixed(1)}m
            </div>
          </div>
          <div className="bg-background/50 rounded-lg p-2 text-center">
            <div className="text-[10px] text-muted-foreground">Height • الارتفاع</div>
            <div className="text-gulf-teal font-mono font-bold text-sm">
              {projectile.maxHeight.toFixed(1)}m
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
