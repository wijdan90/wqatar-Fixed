import React, { useState, useEffect } from 'react';
import { SimulationCanvas } from '@/components/simulation/SimulationCanvas';
import { ControlPanel } from '@/components/simulation/ControlPanel';
import { TaskPanel } from '@/components/simulation/TaskPanel';
import { ExportPanel } from '@/components/simulation/ExportPanel';
import { useProjectileSimulation } from '@/hooks/useProjectileSimulation';
import { Button } from '@/components/ui/button';
import { RotateCcw, Rocket, Wifi, WifiOff, ShieldCheck } from 'lucide-react';
import { db } from '@/lib/firebase';
import { ref, get } from 'firebase/database';

type ProjectileType = 'football' | 'bowling';

const Index = () => {
  const [firebaseConnected, setFirebaseConnected] = useState<boolean | null>(null);
  const [consentAccepted, setConsentAccepted] = useState(false);
  const [projectileType, setProjectileType] = useState<ProjectileType>('football');

  const {
    velocity,
    angle,
    isFlying,
    projectile,
    trajectory,
    currentTask,
    attemptCounts,
    taskSuccesses,
    hintsUsed,
    studentNotes,
    questionAnswers,
    taskTimers,
    tasks,
    sessionId,
    setVelocity,
    setAngle,
    setCurrentTask,
    fire,
    reset,
    fullReset,
    useHint,
    handleNotesChange,
    handleQuestionAnswer,
  } = useProjectileSimulation(projectileType);


  // Check Firebase connection on mount
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const testRef = ref(db, '.info/connected');
        await get(testRef);
        setFirebaseConnected(true);
      } catch (error) {
        console.error('Firebase connection error:', error);
        setFirebaseConnected(false);
      }
    };
    checkConnection();
  }, []);

  // Show consent screen first
  if (!consentAccepted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-card/80 backdrop-blur rounded-xl p-6 border border-gulf-gold/20 space-y-6">
          <div className="text-center space-y-2">
            <ShieldCheck className="w-12 h-12 text-gulf-gold mx-auto" />
            <h1 className="text-xl font-bold text-gulf-gold">Research Study Consent</h1>
            <p className="text-lg font-medium text-gulf-teal" dir="rtl">موافقة الدراسة البحثية</p>
            <p className="text-sm text-muted-foreground">
              Qatar Education Initiative • مبادرة قطر التعليمية
            </p>
          </div>
          
          <div className="space-y-4 text-sm text-foreground/80">
            <p>
              Welcome to the Projectile Motion Lab! This simulation is part of an educational research study.
            </p>
            <p dir="rtl" className="text-right text-muted-foreground">
              مرحباً بك في مختبر حركة المقذوفات! هذه المحاكاة جزء من دراسة بحثية تعليمية.
            </p>
            <div className="bg-background/50 rounded-lg p-4 space-y-2">
              <p className="font-medium text-gulf-teal">📊 Data Collection Notice / إشعار جمع البيانات:</p>
              <ul className="list-disc list-inside space-y-1 text-xs text-muted-foreground">
                <li>Your interactions will be recorded <strong>anonymously</strong></li>
                <li dir="rtl" className="text-right">سيتم تسجيل تفاعلاتك <strong>بشكل مجهول</strong></li>
                <li>No personal information is collected • لا يتم جمع معلومات شخصية</li>
                <li>Data is used for LSTM model training only</li>
                <li dir="rtl" className="text-right">البيانات تُستخدم لتدريب نموذج LSTM فقط</li>
              </ul>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {firebaseConnected === null ? (
              <span className="text-muted-foreground">Checking connection... جاري التحقق</span>
            ) : firebaseConnected ? (
              <>
                <Wifi className="w-4 h-4 text-green-500" />
                <span className="text-green-500">Connected • متصل</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-red-500" />
                <span className="text-red-500">Connection issue • مشكلة في الاتصال</span>
              </>
            )}
          </div>

          <Button
            onClick={() => setConsentAccepted(true)}
            className="w-full bg-gulf-gold hover:bg-gulf-gold/90 text-gulf-navy font-bold"
          >
            <span>I Agree • أوافق</span>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Compact Header */}
      <header className="border-b border-gulf-gold/20 bg-card/50 backdrop-blur-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-gulf-gold to-gulf-teal bg-clip-text text-transparent">
                  Projectile Motion Lab
                </h1>
                <p className="text-[10px] text-muted-foreground" dir="rtl">مختبر حركة المقذوفات</p>
              </div>
              {/* Firebase Status */}
              <div className="flex items-center gap-1">
                {firebaseConnected ? (
                  <Wifi className="w-3 h-3 text-green-500" />
                ) : (
                  <WifiOff className="w-3 h-3 text-red-500" />
                )}
                <span className="text-[10px] text-muted-foreground">
                  {firebaseConnected ? 'Live • مباشر' : 'Offline • غير متصل'}
                </span>
              </div>
            </div>
            <Button
              onClick={fullReset}
              variant="outline"
              size="sm"
              className="border-gulf-gold/50 text-gulf-gold hover:bg-gulf-gold/10 h-7 text-xs"
            >
              <RotateCcw className="w-3 h-3 mr-1" />
              New • جديد
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content - Scrollable */}
      <main className="flex-1 container mx-auto px-4 py-4 overflow-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Sidebar - Controls (Compact) */}
          <div className="lg:col-span-2 space-y-4">
            <ControlPanel
              velocity={velocity}
              angle={angle}
              isFlying={isFlying}
              projectile={projectile}
              projectileType={projectileType}
              onVelocityChange={setVelocity}
              onAngleChange={setAngle}
              onProjectileTypeChange={setProjectileType}
            />
          </div>

          {/* Center - Canvas with Fire/Reset buttons */}
          <div className="lg:col-span-7">
            <div className="bg-card/50 backdrop-blur rounded-xl p-4 border border-gulf-gold/20">
              {/* Fire & Reset buttons inside canvas area */}
              <div className="flex justify-center gap-3 mb-3">
                <Button
                  onClick={fire}
                  disabled={isFlying}
                  className="bg-gulf-gold hover:bg-gulf-gold/90 text-gulf-navy font-bold px-6"
                >
                  <Rocket className="w-4 h-4 mr-2" />
                  Fire • إطلاق
                </Button>
                <Button
                  onClick={reset}
                  variant="outline"
                  className="border-gulf-teal/50 text-gulf-teal hover:bg-gulf-teal/10 px-6"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset • إعادة
                </Button>
              </div>

              <div className="flex justify-center">
                <SimulationCanvas
                  velocity={velocity}
                  angle={angle}
                  projectile={projectile}
                  trajectory={trajectory}
                  isFlying={isFlying}
                  projectileType={projectileType}
                />
              </div>
              
              {/* Physics Info - Compact */}
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="p-2 rounded-lg bg-background/50">
                  <div className="text-[10px] text-muted-foreground">Horizontal • أفقي</div>
                  <div className="text-xs font-mono text-gulf-gold">
                    Vx = {(velocity * Math.cos(angle * Math.PI / 180)).toFixed(1)} m/s
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-background/50">
                  <div className="text-[10px] text-muted-foreground">Vertical • عمودي</div>
                  <div className="text-xs font-mono text-gulf-teal">
                    Vy = {(velocity * Math.sin(angle * Math.PI / 180)).toFixed(1)} m/s
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-background/50">
                  <div className="text-[10px] text-muted-foreground">Gravity • الجاذبية</div>
                  <div className="text-xs font-mono text-muted-foreground">
                    g = 9.81 m/s²
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Tasks & Export */}
          <div className="lg:col-span-3 space-y-4">
            <TaskPanel
              tasks={tasks}
              currentTask={currentTask}
              attemptCounts={attemptCounts}
              taskSuccesses={taskSuccesses}
              hintsUsed={hintsUsed}
              taskTimers={taskTimers}
              onTaskSelect={setCurrentTask}
              onHintClick={useHint}
              onNotesChange={handleNotesChange}
              onQuestionAnswer={handleQuestionAnswer}
              studentNotes={studentNotes}
              questionAnswers={questionAnswers}
            />

            <ExportPanel sessionId={sessionId} />
          </div>
        </div>
      </main>

      {/* Compact Footer */}
      <footer className="border-t border-gulf-gold/20 bg-card/30">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground">
            <span>© 2024 STEM Research • بحث العلوم</span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              Anonymous logging • تسجيل مجهول
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
