import { initializeApp } from "firebase/app";
import { getDatabase, ref, push, get, set, update } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBf0KPc6FQkhVpL_6GNbqxJtiVAcFSC40U",
  authDomain: "phet-research-wejdan.firebaseapp.com",
  databaseURL: "https://phet-research-wejdan-default-rtdb.firebaseio.com",
  projectId: "phet-research-wejdan",
  storageBucket: "phet-research-wejdan.firebasestorage.app",
  messagingSenderId: "1009737031352",
  appId: "1:1009737031352:web:1fb2b212389cfa2c035e4d",
  measurementId: "G-0MWHNP6TFY",
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

export const generateSessionId = (): string => {
  return `session_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
};

export type ProjectileType = "football" | "bowling";

export interface ActionLog {
  sessionId: string;
  sequenceNumber: number;
  timestamp_ms: number;
  actionType: string;
  value: any;

  // Derived behavior code (RO1)
  derivedCode?: string;

  // State snapshot
  state: {
    velocity: number;
    angle: number;
    projectileX: number;
    projectileY: number;
    isFlying: boolean;
    currentTask: number;
    attemptCount: number;
    hintCount: number;
    projectileType?: ProjectileType;
  };

  // Temporal meta
  temporal?: {
    gap_from_previous_ms: number;
    session_time_ms: number;
    challenge_time_ms: number;
  };

  metadata?: Record<string, any>;
}

let sequenceCounter = 0;
export const resetSequenceCounter = () => {
  sequenceCounter = 0;
};

/**
 * Writes session metadata once (or updates).
 * Path:
 *   /sessions/{sessionId}/metadata
 */
export const upsertSessionMetadata = async (
  sessionId: string,
  metadata: Record<string, any>
): Promise<void> => {
  const metaRef = ref(db, `sessions/${sessionId}/metadata`);
  await update(metaRef, {
    ...metadata,
    updatedAt_ms: Date.now(),
  });
};

/**
 * Appends an event to:
 *   /sessions/{sessionId}/events
 */
export const logSessionEvent = async (
  sessionId: string,
  event: Omit<ActionLog, "sessionId" | "sequenceNumber">
): Promise<void> => {
  try {
    sequenceCounter += 1;
    const eventsRef = ref(db, `sessions/${sessionId}/events`);
    await push(eventsRef, {
      sessionId,
      sequenceNumber: sequenceCounter,
      ...event,
    });
  } catch (error) {
    console.error("Error logging event:", error);
  }
};

/**
 * Writes derived metrics to:
 *   /sessions/{sessionId}/temporalMetrics
 */
export const writeTemporalMetrics = async (
  sessionId: string,
  metrics: Record<string, any>
): Promise<void> => {
  try {
    const mRef = ref(db, `sessions/${sessionId}/temporalMetrics`);
    await set(mRef, {
      ...metrics,
      updatedAt_ms: Date.now(),
    });
  } catch (error) {
    console.error("Error writing metrics:", error);
  }
};

/**
 * Stores per-challenge summary:
 *   /sessions/{sessionId}/challenges/{challengeId}
 */
export const writeChallengeSummary = async (
  sessionId: string,
  challengeId: number,
  summary: Record<string, any>
): Promise<void> => {
  try {
    const cRef = ref(db, `sessions/${sessionId}/challenges/${challengeId}`);
    await update(cRef, {
      ...summary,
      updatedAt_ms: Date.now(),
    });
  } catch (error) {
    console.error("Error writing challenge summary:", error);
  }
};

export const getSessionLogs = async (sessionId: string): Promise<ActionLog[]> => {
  try {
    // Backward compatibility: first try new path
    const eventsRef = ref(db, `sessions/${sessionId}/events`);
    const snap = await get(eventsRef);
    if (snap.exists()) {
      const logs: ActionLog[] = [];
      snap.forEach((child) => logs.push(child.val() as ActionLog));
      return logs.sort((a, b) => a.sequenceNumber - b.sequenceNumber);
    }

    // Fallback to old path (legacy)
    const legacyRef = ref(db, "simulation_logs");
    const legacySnap = await get(legacyRef);
    if (!legacySnap.exists()) return [];

    const legacy: any[] = [];
    legacySnap.forEach((child) => {
      const data = child.val();
      if (data.sessionId === sessionId) legacy.push(data);
    });

    return legacy.sort((a, b) => (a.sequenceNumber ?? 0) - (b.sequenceNumber ?? 0)) as ActionLog[];
  } catch (error) {
    console.error("Error fetching logs:", error);
    return [];
  }
};
