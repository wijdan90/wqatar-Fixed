import confetti from 'canvas-confetti';

export const celebrateSuccess = () => {
  // Gulf-inspired colors: gold, teal, cream
  const colors = ['#D4A853', '#2A9D8F', '#F5E6D3', '#FFD700'];

  // First burst
  confetti({
    particleCount: 100,
    spread: 70,
    origin: { y: 0.6 },
    colors,
  });

  // Side cannons
  setTimeout(() => {
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0 },
      colors,
    });
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1 },
      colors,
    });
  }, 150);

  // Stars
  setTimeout(() => {
    confetti({
      particleCount: 30,
      spread: 100,
      origin: { y: 0.5 },
      shapes: ['star'],
      colors: ['#D4A853', '#FFD700'],
      scalar: 1.2,
    });
  }, 300);
};

export const celebrateAllComplete = () => {
  const duration = 3000;
  const end = Date.now() + duration;
  const colors = ['#D4A853', '#2A9D8F', '#F5E6D3', '#FFD700', '#1A365D'];

  const frame = () => {
    confetti({
      particleCount: 5,
      angle: 60,
      spread: 55,
      origin: { x: 0 },
      colors,
    });
    confetti({
      particleCount: 5,
      angle: 120,
      spread: 55,
      origin: { x: 1 },
      colors,
    });

    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  };
  frame();
};
